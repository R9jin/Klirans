using UnityEngine;
using UnityEngine.UI;

public class PlayerInteract : MonoBehaviour
{
    [Header("Interaction Settings")]
    [SerializeField] private float interactRange = 3f;

    [Tooltip("The layers that can be interacted with. Make sure the Flashlight's colliders are on one of these layers.")]
    [SerializeField] private LayerMask interactableLayer;

    [Header("Interaction UI")]
    [SerializeField] private Text promptText;

    private Camera playerCamera;

    private PickupItem currentTarget;

    private void Start()
    {
        // Find the camera attached to the player or one of its children.
        playerCamera = GetComponentInChildren<Camera>();

        if (playerCamera == null)
        {
            Debug.LogError(
                "PlayerInteract could not find a Camera. " +
                "Make sure the Player has a Camera component on itself or one of its children."
            );
        }

        // Hide the interaction prompt when the game starts.
        if (promptText != null)
        {
            promptText.gameObject.SetActive(false);
        }
        else
        {
            Debug.LogWarning(
                "PlayerInteract has no Prompt Text assigned. " +
                "The interaction may work, but the 'Press E to Pick Up' message cannot be displayed."
            );
        }
    }

    private void Update()
    {
        if (playerCamera == null)
        {
            return;
        }

        // Create a ray from the exact center of the player's screen.
        Ray ray = playerCamera.ViewportPointToRay(
            new Vector3(0.5f, 0.5f, 0f)
        );

        RaycastHit hit;

        // Cast the ray forward from the player's camera.
        if (Physics.Raycast(
            ray,
            out hit,
            interactRange,
            interactableLayer,
            QueryTriggerInteraction.Collide
        ))
        {
            // Search the object that was hit and all of its parents
            // for a PickupItem component.
            //
            // Example:
            //
            // Flashlight
            // ├── Back
            // ├── Base
            // ├── Button
            // ├── ButtonDesign
            // ├── Glass
            // └── PickupItem
            //
            // If the ray hits Glass:
            //
            // Glass
            //    ↑
            //    │ GetComponentInParent
            //    │
            // Flashlight
            //    └── PickupItem
            //
            // The PickupItem on Flashlight will be found.
            PickupItem pickupItem = hit.collider.GetComponentInParent<PickupItem>();

            if (pickupItem != null)
            {
                SetCurrentTarget(pickupItem);

                // Show the pickup prompt.
                if (promptText != null)
                {
                    promptText.text = "Press E to Pick Up";
                    promptText.gameObject.SetActive(true);
                }

                // Pick up the item when E is pressed.
                if (Input.GetKeyDown(KeyCode.E))
                {
                    pickupItem.Interact();
                }

                return;
            }
        }

        // Nothing interactable is currently being looked at.
        ClearCurrentTarget();
    }

    private void SetCurrentTarget(PickupItem pickupItem)
    {
        if (currentTarget == pickupItem)
        {
            return;
        }

        currentTarget = pickupItem;
    }

    private void ClearCurrentTarget()
    {
        if (currentTarget == null)
        {
            return;
        }

        currentTarget = null;

        if (promptText != null)
        {
            promptText.gameObject.SetActive(false);
        }
    }

    private void OnDrawGizmosSelected()
    {
        // Draw the interaction ray in the Scene view when the player
        // is selected, making it easier to see the interaction range.
        if (playerCamera == null)
        {
            return;
        }

        Gizmos.color = Color.yellow;

        Ray ray = playerCamera.ViewportPointToRay(
            new Vector3(0.5f, 0.5f, 0f)
        );

        Gizmos.DrawRay(
            ray.origin,
            ray.direction * interactRange
        );
    }
}